![Vistas del repositorio](https://komarev.com/ghpvc/?username=Eliasar54&repo=SAMURAI-BOT&label=Vistas%20del%20repositorio&color=green&style=for-the-badge)


<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Oswald&weight=300&size=37&duration=3000&pause=100&color=FF5733&background=601D6E00&center=true&vCenter=true&repeat=true&random=FALSO&width=660&height=90&lines=YuGi-BOT+%C2%A1evolucion%C3%B3!;Ahora+se+llama+SAMURAI-BOT; un+bot+con+tem%C3%A1tica+samurai+hecho+por+fans+para+fans." alt="Typing SVG"/></a>
</div>

<p align="center">
  <img src="https://telegra.ph/file/31e89872f6c098cf8b161.jpg" alt="ELIASAR-YT" width="900" />
</p>

### `👑 DUDAS SOBRE EL BOT?, CONTACTAME 👑`
<p align="center">
<a href="https://github.com/Eliasar54"><img src="http://readme-typing-svg.herokuapp.com?font=mono&size=14&duration=3000&color=ABF7BB&center=verdadero&vCenter=verdadero&lines=Solo+escr%C3%ADba+si+tiene+dudas." height="40px"
</p>
    
<a href="https://wa.me/message/WIOCUMWR26RZE1" target="blank"><img src="https://img.shields.io/badge/Creador-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /></a>
 
 
<a href="https://whatsapp.com/channel/0029Vae6j714Y9loutP3Au29" target="_blank">
    <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp" width="30" height="30"/>
    <strong>Ir al canal oficial</strong>
</a>

------------------ 
 

## INSTALA EN TERMUX
👇 Pasos para instalar el bot via termux 👇



[`💫 Instalar termux clic aqui`](https://www.mediafire.com/file/3hsvi3xkpq3a64o/termux_118.apk/file)

```bash
termux-setup-storage
```
```bash
apt update && apt upgrade && pkg update && pkg upgrade && pkg install bash && pkg install libwebp && pkg install git -y && pkg install nodejs -y && pkg install ffmpeg -y && pkg install wget && pkg install imagemagick -y && pkg install yarn
```
```bash
git clone https://github.com/Eliasar54/SAMURAI-BOT &&  cd SAMURAI-BOT && npm install
```
```bash
npm start
```

### `🏵️ 𝙰𝙲𝚃𝙸𝚅𝙰𝚁 𝙴𝙽 𝙲𝙰𝚂𝙾 𝙳𝙴 𝙳𝙴𝚃𝙴𝙽𝙴𝚁𝚂𝙴 𝙴𝙽 𝚃𝙴𝚁𝙼𝚄𝚇`
Si despues que ya instalastes tu bot y termux te salta en blanco, se fue tu internet o reiniciaste tu celular, solo realizaras estos pasos
```bash
>  cd SAMURAI-BOT
> npm start
```
### `🏵️ 𝙾𝙱𝚃𝙴𝙽𝙴𝚁 𝙾𝚃𝚁𝙾 𝙲𝙾𝙳𝙸𝙶𝙾 𝚀𝚁 𝙴𝙽 𝚃𝙴𝚁𝙼𝚄𝚇`
Detener el bot apretado CTRL y aplastas Z en tu teclado, darle enter y escribe:
```bash
> cd 
> cd SAMURAI-BOT
> rm -rf sessions
> npm start
```



> Warning Estos comandos solo funcionan para TERMUX, REPLIT, LINUX

### `🤖 𝙿𝙰𝚁𝙰 𝙰𝙲𝚃𝙸𝚅𝙰𝚁 𝟸𝟺/𝟽 (𝚃𝙴𝚁𝙼𝚄𝚇)`
```bash
npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
```
### 🔰 NEXUS-HOST 
<a href="https://nexus-host.shop"><img src="https://qu.ax/KFqK.jpg" height="125px"></a>
### Información del Host

- **Dashboard:** [`Aquí`](https://dash.nexus-host.shop)
- **Panel:** [`Aquí`](https://panel.nexus-host.shop)
- **Grupo de WhatsApp:** [`Aquí`](https://chat.whatsapp.com/DlErIXnbKfx4AvvyngFuSX)
-
